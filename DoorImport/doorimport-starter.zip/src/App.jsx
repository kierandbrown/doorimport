export default function App() {
  return (
    <div className="bg-green-500 text-white p-4 text-xl">
      Tailwind is working ✅
    </div>
  );
}
